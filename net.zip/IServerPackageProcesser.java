package swarm_wars_library.network;

public interface IServerPackageProcesser {

    public void sendpackage() throws InterruptedException;

}
