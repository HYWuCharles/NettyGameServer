
public class Headers {

    public static final String TYPE = "T";

    public static final String W = "W";

    public static final String S = "S";

    public static final String A = "A";

    public static final String D = "D";

    public static final String MOUSE_X = "X";

    public static final String MOUSE_Y = "Y";

    public static final String MOUSE_PRESSED = "C";

    public static final String MOUSE_LEFT_PRESSED = "MLP";

    public static final String MOUSE_RIGHT_PRESSED = "MRP";

    public static final String PLAYER_NUMBER  ="N";

    public static final String FRAME = "F";

    public static final String PLAYER = "P";

    public static final String RANDOM_SEED = "R";

    public static final String STATES = "S";

    public static final String TRANSITIONS = "TR";

    public static final String SWARM_LOGIC = "SL";
}
