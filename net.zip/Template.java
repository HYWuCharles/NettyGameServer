package swarm_wars_library.network;

public class Template {
  
}