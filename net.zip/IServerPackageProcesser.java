
public interface IServerPackageProcesser {

    public void sendpackage() throws InterruptedException;

}
